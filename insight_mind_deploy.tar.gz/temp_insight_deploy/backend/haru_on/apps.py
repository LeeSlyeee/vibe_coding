from django.apps import AppConfig


class HaruOnConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "haru_on"
